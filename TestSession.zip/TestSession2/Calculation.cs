﻿namespace TestSession2
{
    public static class Calculation
    {
        private static readonly List<string> posts = ["Директор", "Мастер", "Водитель"];
        public static double SalaryCalculation(string post, float bet)
        {
            if (!posts.Contains(post))
            {
                return -1;
            }
            if (bet <= 0)
            {
                return -1;
            }
            double tax = 0.87;
            double postSalary = post switch
            {
                "Директор" => 30000,
                "Мастер" => 20000,
                "Водитель" => 15000
            };

            double salary = postSalary * bet * tax;

            return salary;
        }
    }
}
