﻿using TestSession2;

namespace TestSession2Test
{
    [TestClass]
    public sealed class LowDifficultyTests
    {
        [TestMethod]
        public void SalaryCalculation_Director_1point9_49590()
        {
            double result = Calculation.SalaryCalculation("Директор", 1.9F);
            double expected = 30000 * 0.87 * 1.9F;
            Assert.AreEqual(expected, result);
        }
        [TestMethod]
        public void SalaryCalculation_Master_1point9_33060()
        {
            double result = Calculation.SalaryCalculation("Мастер", 1.9F);
            double expected = 20000 * 0.87 * 1.9F;
            Assert.IsTrue(expected == result);
        }
        [TestMethod]
        public void SalaryCalculation_Driver_1point9_24795()
        {
            double result = Calculation.SalaryCalculation("Водитель", 1.9F);
            double expected = 15000 * 0.87 * 1.9F;
            Assert.AreEqual(expected, result);
        }
        [TestMethod]
        public void SalaryCalculation_Director_1point9_IsDouble()
        {
            double result = Calculation.SalaryCalculation("Директор", 1.9F);
            Assert.IsInstanceOfType(result, typeof(double));
        }
        [TestMethod]
        public void SalaryCalculation_Director_2point1_IsBigger_Director_1point9()
        {
            double result1 = Calculation.SalaryCalculation("Директор", 1.9F);
            double result2 = Calculation.SalaryCalculation("Директор", 2.1F);
            Assert.IsTrue(result1 < result2);
        }
        [TestMethod]
        public void SalaryCalculation_Master_1point9_IsNotMoreThen_Director_1point9()
        {
            double result1 = Calculation.SalaryCalculation("Мастер", 1.9F);
            double result2 = Calculation.SalaryCalculation("Директор", 1.9F);
            Assert.IsFalse(result1 > result2);
        }
        [TestMethod]
        public void SalaryCalculation_Director_1point0_TaxCalculation()
        {
            double result = Calculation.SalaryCalculation("Директор", 1.0F);
            double expected = 30000 * 0.87;
            Assert.AreEqual(expected, result);
        }
        [TestMethod]
        public void SalaryCalculation_Director_1point0_Equal_Driver_2point0()
        {
            double result1 = Calculation.SalaryCalculation("Директор", 1.0F);
            double result2 = Calculation.SalaryCalculation("Водитель", 2.0F);
            Assert.IsTrue(result1 == result2);
        }
        [TestMethod]
        public void SalaryCalculation_Director_2421point125_63191362point5()
        {
            double result = Calculation.SalaryCalculation("Директор", 2421.125F);
            double expected = 63191362.5;
            Assert.AreEqual(expected, result);
        }
        [TestMethod]
        public void SalaryCalculation_Driver_0point0001_1point305()
        {
            double result = Calculation.SalaryCalculation("Водитель", 0.0001F);
            double expected = 15000 * 0.87 * 0.0001F;
            Assert.AreEqual(expected, result);
        }
    }
}
