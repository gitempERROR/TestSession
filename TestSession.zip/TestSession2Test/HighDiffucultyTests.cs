﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestSession2;

namespace TestSession2Test
{
    [TestClass]
    public sealed class HighDiffucultyTests
    {
        [TestMethod]
        public void SalaryCalculation_Director_0point0_negative1()
        {
            double result = Calculation.SalaryCalculation("Директор", 0.0F);
            double expected = -1;
            Assert.AreEqual(expected, result);
        }
        [TestMethod]
        public void SalaryCalculation_Master_negative1point9_negative1()
        {
            double result = Calculation.SalaryCalculation("Мастер", -1.9F);
            double expected = -1;
            Assert.IsTrue(expected == result);
        }
        [TestMethod]
        public void SalaryCalculation_Driver_0point0_negative1()
        {
            double result = Calculation.SalaryCalculation("Водитель", 0.0F);
            double expected = -1;
            Assert.AreEqual(expected, result);
        }
        [TestMethod]
        public void SalaryCalculation_Director_null_IsDouble()
        {
            double result = Calculation.SalaryCalculation("Директор", Convert.ToSingle(null));
            Assert.IsInstanceOfType(result, typeof(double));
        }
        [TestMethod]
        public void SalaryCalculation_NonExistentPost_1point9_negative1()
        {
            double result = Calculation.SalaryCalculation("Driver", 1.9F);
            double expected = -1;
            Assert.AreEqual(expected, result);
        }
    }
}
